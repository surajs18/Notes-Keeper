var data = {};
var remed = {};
if (window.localStorage.getItem("data1") == null) {
    window.localStorage.setItem("data1", encodeURI(JSON.stringify(data))); //existing
}
if (window.localStorage.getItem("data2") == null) {
    window.localStorage.setItem("data2", encodeURI(JSON.stringify(remed))); //deleted
}
form = document.getElementById("new");

//Create

form.addEventListener('submit', function(event) {
    event.preventDefault();
    crte();
});

function crte() {
    let url = document.URL;
    let surl = url.split('=');

    let dat = JSON.parse(decodeURI(window.localStorage.getItem("data1")));
    let dat2 = JSON.parse(decodeURI(window.localStorage.getItem("data2"))); //get from local.storage
    var title = document.getElementById("new").elements[0].value;
    var txt = document.getElementById("new").elements[1].value;
    var d = new Date(Date.now());
    let i;
    if (Object.keys(dat).length === 0) {
        i = 0;
    } else {
        let a1 = Object.keys(dat);
        let a2 = Object.keys(dat);
        let b1 = Object.keys(dat).length;
        let b2 = Object.keys(dat2).length;
        i = parseInt(a1[b1 - 1]) + 1;
        let j = parseInt(a2[b2 - 1]) + 1;
        if (j > i)
            i = j;
    }
    let l = surl.length;
    if (l == 2) {
        i = parseInt(surl[1]);
    }
    let date = d.toString();
    let value = [title, txt, date];
    dat[i] = value;
    window.localStorage.setItem("data1", encodeURI(JSON.stringify(dat))); //set from local.storage
    sendJSON();
    window.location.href = "SN_Disp.html";

}

//Display

function disptxt() {

    let dat = JSON.parse(decodeURI(window.localStorage.getItem("data1")));
    if (Object.keys(dat).length === 0) {
        let s = "<h4 class='empty'>Itssss sooooooo emptyyyy hereeee <br> Please fill me up🤧🤧🤧🤧🤧</h4>"
        $("#disp").html(s);
        $('.cool').html("");
    } else {
        for (i in dat) {
            let title = dat[i];
            y = title[0].substring(0, 10);
            x = "<div class='card' id=\"" + i + "\"> <div class='container'> <h4 class='tint'><b>" + y + "</b></h4><div class='edit' onclick='edit(\"" + i + "\")'><i class='far fa-edit' title='Edit'></i></div><div class='cls' onclick='rem(\"" + i + "\")'><i class='far fa-window-close' title='Delete'></i></div> </div></div>";
            $('#disp').append(x);
            $('.cool').html("");
            $('.cool').append("Add on meh😋😋😋");
        }
    }
}

//Display Removed
function disprem() {
    let dat = JSON.parse(decodeURI(window.localStorage.getItem("data2")));
    if (Object.keys(dat).length === 0) {
        let s = "<h4 class='empty'>Trust me I'll kill all your data😤😤😤</h4>"
        $("#disprem").html(s);
        $('.cool').html("");
    } else {
        for (i in dat) {
            let title = dat[i];
            y = title[0].substring(0, 10);
            x = "<div class='card' id=\''+i'\'> <div class='container'> <h4 class='tint'><b>" + y + "</b></h4><div class='edit' onclick='restore(\"" + i + "\")'><i class='fas fa-trash-restore' title='Restore'></i></div><div class='cls' onclick='remrem(\"" + i + "\")'><i class='far fa-window-close' title='Delete Permanently'></i></div> </div></div>";
            $('#disprem').append(x);
            $('.cool').html("");
            $('.cool').append("Save me please🥺🥺🥺");
        }
    }
}

//Edit

function edit(index) {
    window.location.href = "SN_New.html?a=" + index + "";

}

function edit2() {
    var url = window.location.href;
    var params = {};
    let parser = document.createElement('a');
    parser.href = url;
    let query = parser.search.substring(1);
    let vars = query.split('&');
    for (var i = 0; i < vars.length; i++) {
        var pair = vars[i].split('=');
        params[pair[0]] = decodeURIComponent(pair[1]);
    }
    if (params.a != null) {
        let dat = JSON.parse(decodeURI(window.localStorage.getItem("data1")));
        let title = dat[params.a];
        document.getElementsByClassName("title")[0].value = title[0];
        let con = dat[params.a]
        let content = document.getElementsByClassName("content");
        let n = con[1].split("\n");
        let nl = "\n";
        for (i in n) {
            if (i > 0) {
                content.body.innerHTML = content.body.value + nl + n[i];
            } else {
                content.body.innerHTML = n[i];
            }
        }
        $('.info').append((con[2]).substring(3, 25));
    }

}

//Remove the particular entity

function rem(item) {
    let dat = JSON.parse(decodeURI(window.localStorage.getItem("data1")));
    let dat2 = JSON.parse(decodeURI(window.localStorage.getItem("data2")));
    dat2[item] = dat[item]
    delete dat[item];
    window.localStorage.setItem("data1", encodeURI(JSON.stringify(dat)));
    window.localStorage.setItem("data2", encodeURI(JSON.stringify(dat2)));
    $("#disp").html("");
    sendJSON();
    disptxt();
}

//Search for an existing entity

function search() {
    var input, filter, d = [],
        a, i, txtValue;
    input = document.getElementById("search");
    filter = input.value.toUpperCase();
    d = document.getElementsByClassName("card");
    for (i = 0; i < d.length; i++) {
        a = d[i].getElementsByTagName("b")[0];
        txtValue = a.textContent || a.innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
            d[i].style.display = "";
        } else {
            d[i].style.display = "none";
        }
    }
}

//Restore

function restore(item) {
    let dat = JSON.parse(decodeURI(window.localStorage.getItem("data1")));
    let dat2 = JSON.parse(decodeURI(window.localStorage.getItem("data2")));
    dat[item] = dat2[item]
    delete dat2[item];
    window.localStorage.setItem("data1", encodeURI(JSON.stringify(dat)));
    window.localStorage.setItem("data2", encodeURI(JSON.stringify(dat2)));
    $("#disprem").html("");
    sendJSON();
    disprem();
    window.location.href = 'SN_Disp.html';
}

//Remove from everywhere

function remrem(item) {
    let res = confirm('Are you sure you want to delete it permanently?');
    if (res) {
        let dat2 = JSON.parse(decodeURI(window.localStorage.getItem("data2")));
        delete dat2[item];
        window.localStorage.setItem("data2", encodeURI(JSON.stringify(dat2)));
        $("#disprem").html("");
        sendJSON();
        disprem();
    }
}

//Delete all the records

function dell() {
    t = confirm('Are you sure you want to delete them all?');
    if (t) {
        let dat = JSON.parse(decodeURI(window.localStorage.getItem("data1")));
        let dat2 = JSON.parse(decodeURI(window.localStorage.getItem("data2")));
        for (i in dat) {
            dat2[i] = dat[i];
        }
        window.localStorage.setItem("data2", encodeURI(JSON.stringify(dat2)));
        window.localStorage.setItem("data1", encodeURI(JSON.stringify(data)))
        sendJSON()
        disptxt();
    }
}

//Go Home
function gohome() {
    window.location.href = 'SN_Main.html';
}

//Server Side AJAX call

function sendJSON() {
    let dat = JSON.parse(decodeURI(window.localStorage.getItem("data1")));
    let dat2 = JSON.parse(decodeURI(window.localStorage.getItem("data2")));
    $.ajax({
        type: 'POST',
        url: '/dispinfo',
        data: JSON.stringify(dat),
        contentType: "application/json; charset=utf-8",
        traditional: true,
    })
    $.ajax({
        type: 'POST',
        url: '/dltinfo',
        data: JSON.stringify(dat2),
        contentType: "application/json; charset=utf-8",
        traditional: true,
    })
}