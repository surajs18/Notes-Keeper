//Login Page
function logon() {
    //Email
    let str = $(".mail1").val();
    let patt = /^\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b$/i;

    if (str == "") {
        $(".mail1").focus();
        $(".er").text("Please Enter Email ID");
        $(".mail1").css("border", "2px solid red");
        return;
    }
    if (!patt.test(str)) {
        $(".er").text("Incorrect Email ID");
        $(".mail1").val("");
        $(".mail1").focus();
        $(".mail1").css("border", "2px solid red");
        return;
    }
    //Password
    if ($(".pass").val() == "") {
        $(".er").text("Please Enter Your Password");
        $(".pass").focus();
        $(".pass").css("border", "2px solid red");
    } else {
        $(".mail1").css("border", "2px solid green");
        $(".pass").css("border", "2px solid green");
        Login($(".mail1"), $(".pass"))
    }
}

//View Password on login page
function vpass(el) {
    if (el.checked)
        $(".pass").attr("type", "text");
    else
        $(".pass").attr("type", "password");
}

//View password on Create Account page
function vpass2(el) {
    if (el.checked) {
        $(".pass1").attr("type", "text");
        $(".pass2").attr("type", "text");
    } else {
        $(".pass1").attr("type", "password");
        $(".pass2").attr("type", "password");
    }
}

//Changing from login --> Create page
function change1() {
    $('#sub').css('display', '');
    $('#main').css('display', 'none');
}

//Changing from Create --> Login page
function change2() {
    $('#main').css('display', '');
    $('#sub').css('display', 'none');
}

//Create Account
function comppass() {
    //Email
    let str = $(".mail2").val();
    let patt = /^\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b$/i;
    if (!patt.test(str)) {
        $(".er1").text("Incorrect Email ID");
        $(".mail2").val("");
        $(".mail2").focus();
        return;
    }

    //Password
    if ($(".pass1").val() != "" && $(".pass2").val() != "") {
        if ($(".pass1").val() == $(".pass2").val()) {
            $(".pass1").css("border", "2px solid green");
            $(".pass2").css("border", "2px solid green");
            $(".er1").text("Creating Account");
            createme($(".mail2"), (".pass1"))
            $(".mail2").val("");
            $(".pass1").val("");
            $(".pass2").val("");
        } else if ($(".pass1").val() != $(".pass2").val()) {
            $(".pass1").css("border", "2px solid red");
            $(".pass2").css("border", "2px solid red");
            $(".er1").text("Password Not Matching");
            $(".pass2").focus();
        }
    } else {
        $(".er1").text("Please Enter Password");
    }
}

//Login AJAX

//Login
function Login(usnam, pasword) {
    let login = { usnam: pasword };
    $.ajax({
        type: 'POST',
        url: '/lo-gin-1',
        data: JSON.stringify(login),
        contentType: "application/json; charset=utf-8",
        traditional: true,
    })
}

//Create Acc
function createme(usnam, pasword) {
    let login = { usnam: pasword };
    $.ajax({
        type: 'POST',
        url: '/lo-gin-2',
        data: JSON.stringify(login),
        contentType: "application/json; charset=utf-8",
        traditional: true,
    })
}