const express = require('express')
const fs = require('fs')
const mongoose = require('mongoose')
const app = express()
const port = 3334;

//connection to mongodb
mongoose.connect('mongodb://localhost:27017/WTACT')
const db = mongoose.connection;
db.once('open', () => {
    console.log("connected");
})

app.use(express.static('./Login')); //fetching all html, css, js(client)
app.use(express.json()); //receiving json data from ajax

//receiving Login data & Validating login & loding data to browser
app.post('/lo-gin-1', function(request, response, next) {
    let d = request.body;
    let x, dat, dat2;
    if (db.collection("Login").find(d)) {
        console.log("Login Success");
        for (x in d) {
            dat = db.collection("Disp").find({ x: { $exists: true } })
            dat2 = db.collection("Deleted").find({ x: { $exists: true } })
        }
        console.log(dat + "\n\n\n" + dat2)
            //res.redirect('/');
    }

});

//receiving Create Account data & pushing data to db
app.post('/lo-gin-2', function(request, response) {
    let { usnam, paswrd } = request.body;
    if (db.collection("Login").countDocuments({ usnam: { $exists: true } })) {
        console.log("Account Already Exists");
        console.log(db.collection("Login").countDocuments({ usnam: { $exists: true } }))
    } else {
        db.collection("Login").insertOne(d, function(err, res) {
            if (err)
                console.log("Error Creating Account");
            else
                console.log("Created Account");
        })
    }

});

//Reset Password

//Delete Account

//Piping the Login Page 
app.get('/login', function(req, res) {
    res.writeHead(200, { 'Contact-Type': 'text/html' });
    fs.createReadStream('./Login/login.html').pipe(res);
});

//Posting 404 error 
app.use(function(request, response) {
    var err = new Error('Not Found');
    err.status = 404;
    response.writeHead(404, { 'Content-Type': 'text/html' });
    response.write('<h1>404:</h1>\n <h2>Page Not Found</h2>');
    response.end();
});

//Listening on to the port
app.listen(port, () => console.log(`http:///localhost:${port}/login`))