const express = require('express')
const fs = require('fs')
const mongoose = require('mongoose')
const app = express()
const port = 3334;

//connection to mongodb
mongoose.connect('mongodb://localhost:27017/WTACT')
const db = mongoose.connection;

db.once('open', () => {
    console.log("connected");
})

app.use(express.static('./public')); //fetching all html, css, js(client)
app.use(express.json()); //receiving json data from ajax

//receiving displaying data & pushing data to db 
app.post('/dispinfo', function(request, response) {
    let d = { "suraj": request.body };
    if (db.collection("Disp").find({ "suraj": { $exists: true } })) {
        db.collection("Disp").deleteOne({ "suraj": { $exists: true } });
        console.log("found disp");
    }
    db.collection("Disp").insertOne(d, function(err, res) {
        if (err)
            console.log("Error in Disp");
        else
            console.log("Success in Disp");
    })

});

//receiving deleted data & pushing data to db 
app.post('/dltinfo', function(request, response) {
    let d = { "suraj": request.body };
    if (db.collection("Deleted").find({ "suraj": { $exists: true } })) {
        db.collection("Deleted").deleteOne({ "suraj": { $exists: true } });
        console.log("found deletd");
    }
    db.collection("Deleted").insertOne(d, function(err, res) {
        if (err)
            console.log("Error in Deleted");
        else
            console.log("Success in Deleted");
    })

});

//send data to client 

//Piping the 1st page though to make the whole project work 
app.get('/', function(req, res) {
    res.writeHead(200, { 'Contact-Type': 'text/html' });
    fs.createReadStream('./public/SN_Main.html').pipe(res);
});

//Posting 404 error 
app.use(function(request, response) {
    var err = new Error('Not Found');
    err.status = 404;
    response.writeHead(404, { 'Content-Type': 'text/html' });
    response.write('<h1>404:</h1>\n <h2>Page Not Found</h2>');
    response.end();
});

//Listening on to the port
app.listen(port, () => console.log(`http:///localhost:${port}`))